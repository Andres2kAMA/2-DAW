"use strict";
//*** Enlace a las bibliotecas Firebase -> https://firebase.google.com/docs/web/learn-more?authuser=0#libraries-cdn

/**
 * Este fichero será la 'key' para conectarme con Firebase.
 * Desde aquí se exportará la constante que servirá para conectarse con los repositorios de Firebase.
 */

import { initializeApp } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-app.js";
import { getAuth } from "https://www.gstatic.com/firebasejs/9.6.1/firebase-auth.js";

const firebaseConfig = {
  apiKey: "AIzaSyC7XNhZSz1ZxlvPpH1ypNJ3cp63C-V3pVM",

  authDomain: "productos-566b7.firebaseapp.com",

  projectId: "productos-566b7",

  storageBucket: "productos-566b7.appspot.com",

  messagingSenderId: "167973263940",

  appId: "1:167973263940:web:933ef4af6f790802d9fa11",
};

const app = initializeApp(firebaseConfig);
const autentificacion = getAuth(app);

export { app, autentificacion };
