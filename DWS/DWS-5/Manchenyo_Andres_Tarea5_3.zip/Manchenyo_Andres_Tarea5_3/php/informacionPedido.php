<div id="infoPedidos">
    <p id="vacio">Ningún producto añadido al carrito</p>

</div>